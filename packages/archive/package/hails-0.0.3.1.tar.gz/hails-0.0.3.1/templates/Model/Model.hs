module Model.Model where

data Model = Model
  { 
  }

emptyBM :: Model
emptyBM = Model
