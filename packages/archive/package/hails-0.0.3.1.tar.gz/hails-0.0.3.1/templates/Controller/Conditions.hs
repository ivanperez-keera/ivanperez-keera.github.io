module Controller.Conditions where

import CombinedEnvironment

installHandlers :: CEnv -> IO ()
installHandlers cenv = do
  return ()
