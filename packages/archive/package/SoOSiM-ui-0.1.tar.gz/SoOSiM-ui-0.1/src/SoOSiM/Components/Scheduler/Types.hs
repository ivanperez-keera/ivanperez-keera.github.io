module SoOSiM.Components.Scheduler.Types where

import SoOSiM

data SchedulerState = SchedulerState
