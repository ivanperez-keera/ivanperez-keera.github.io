module Controller.Conditions.UpdateStatus where

-- External imports
import Data.CBMVar
import Control.Monad
import Graphics.UI.Gtk
import Hails.MVC.Model.ProtectedModel.Reactive

-- Local imports
import CombinedEnvironment
import Controller.Helpers.NextSimState
import Model.Model

installHandlers :: CEnv -> IO()
installHandlers cenv = void $ do
  timeoutAdd (condition cenv) 1000
  model cenv `onEvent` StatusChanged $ void $ condition cenv

condition :: CEnv -> IO Bool
condition cenv = do
  -- Get status and speed from the model
  st <- getter statusField pm
  sp <- getter speedField pm

  -- If the system is actually running, update the state
  when (st == Running && sp > 0) $ do
    modifyCBMVar mcsRef nextStep

  -- If the system is not paused or stopped,
  -- reupdate after a delay
  when (st == Running) $ void $
    let wt = if sp == 0 then 2 else sp
    in timeoutAdd (condition cenv) (round (1000 / wt))

  -- Always stop executing (the timeout handler will
  -- be reinstalled at each step)
  return False

  where mcsRef = mcs (view cenv)
        pm     = model cenv

